import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

class AndrewMuseum {
	private JFrame startFrame;
	private JLabel welcomeText;

	public AndrewMuseum() {
		startFrame = new JFrame("Andrew's Museum");
		startFrame.setSize(400, 200);

		welcomeText = new JLabel("Welcome to Andrew's running Museum", JLabel.CENTER);
		startFrame.add(welcomeText, BorderLayout.CENTER);

		startFrame.addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent windowEvent){
                System.exit(0);
            }        
        });

        
        startFrame.setLayout(new BorderLayout());

        JLabel instructionText = new JLabel("Press Buttons to see pictures from Andrew's running career", JLabel.CENTER);
        startFrame.add(instructionText, BorderLayout.NORTH);

        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new FlowLayout());

        JButton Picture1 = new JButton("Picture 1");
        Picture1.setActionCommand("P1");
        Picture1.addActionListener(new ButtonClickListener());

        JButton Picture2 = new JButton("Picture 2");
        Picture2.setActionCommand("P2");
        Picture2.addActionListener(new ButtonClickListener());

        JButton Picture3 = new JButton("Picture 3");
        Picture3.setActionCommand("P3");
        Picture3.addActionListener(new ButtonClickListener());

        JButton Picture4 = new JButton("Picture 4");
        Picture4.setActionCommand("P4");
        Picture4.addActionListener(new ButtonClickListener());

        JButton Picture5 = new JButton("Picture 5");
        Picture5.setActionCommand("P5");
        Picture5.addActionListener(new ButtonClickListener());

        buttonPanel.add(Picture1);
        buttonPanel.add(Picture2);
        buttonPanel.add(Picture3);
        buttonPanel.add(Picture4);
        buttonPanel.add(Picture5);



       	startFrame.add(buttonPanel, BorderLayout.SOUTH);
        startFrame.setVisible(true);


	}


	private class ButtonClickListener implements ActionListener{
		public void actionPerformed(ActionEvent e) {
			String command = e.getActionCommand();

  		if (command.equals("P1")) {

			JFrame p1Frame = new JFrame();
			JPanel p1Panel = new JPanel();
			ImageIcon icon = new ImageIcon("Picture1.png");
			JLabel Picture1 = new JLabel(icon);

			p1Panel.add(Picture1);
			p1Frame.add(p1Panel);
			p1Frame.pack();
			p1Frame.setVisible(true);     
        }

        if (command.equals("P2")) {

			JFrame p2Frame = new JFrame();
			JPanel p2Panel = new JPanel();
			ImageIcon icon = new ImageIcon("Picture2.png");
			JLabel Picture2 = new JLabel(icon);

			p2Panel.add(Picture2);
			p2Frame.add(p2Panel);
			p2Frame.pack();
			p2Frame.setVisible(true);     
        }
        if (command.equals("P3")) {

			JFrame p3Frame = new JFrame();
			JPanel p3Panel = new JPanel();
			ImageIcon icon = new ImageIcon("Picture3.png");
			JLabel Picture3 = new JLabel(icon);

			p3Panel.add(Picture3);
			p3Frame.add(p3Panel);
			p3Frame.pack();
			p3Frame.setVisible(true);     
        }

        if (command.equals("P4")) {

			JFrame p4Frame = new JFrame();
			JPanel p4Panel = new JPanel();
			ImageIcon icon = new ImageIcon("Picture4.png");
			JLabel Picture4 = new JLabel(icon);

			p4Panel.add(Picture4);
			p4Frame.add(p4Panel);
			p4Frame.pack();
			p4Frame.setVisible(true);     
        }

        if (command.equals("P5")) {

			JFrame p5Frame = new JFrame();
			JPanel p5Panel = new JPanel();
			ImageIcon icon = new ImageIcon("Picture5.png");
			JLabel Picture5 = new JLabel(icon);

			p5Panel.add(Picture5);
			p5Frame.add(p5Panel);
			p5Frame.pack();
			p5Frame.setVisible(true);     
      		}

    	}
	}



	public static void main(String[] args) {
		AndrewMuseum running = new AndrewMuseum();
	}
}
